#include <SFML/Graphics.hpp>

int main() {
    // VideoMode usa sf::Vector2u en SFML 3
    sf::RenderWindow window(sf::VideoMode({300, 300}), "Prueba SFML");

    while (window.isOpen()) {
        // pollEvent devuelve std::optional<sf::Event> en SFML 3
        while (auto eventOpt = window.pollEvent()) {
            sf::Event event = *eventOpt;
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        window.display();
    }

    return 0;
}