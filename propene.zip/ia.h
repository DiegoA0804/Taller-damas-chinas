#ifndef IA_H
#define IA_H

void movimientoIA(char tablero[8][8]);

#endif